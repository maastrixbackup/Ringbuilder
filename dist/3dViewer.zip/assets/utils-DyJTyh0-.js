const r=()=>"https://dev.maastrixdemo.com/ring_builder/public/api/";export{r as b};
